import React from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router';
import { Navbar } from './components/Navbar';
import { Toaster } from 'sonner';
import { useAppContext } from './context/AppContext';

export const Root = () => {
  const { user, logout } = useAppContext();
  const location = useLocation();
  const navigate = useNavigate();

  const isDashboard = location.pathname.startsWith('/admin');
  const isAuth = location.pathname === '/login' || location.pathname === '/register' || location.pathname === '/admin/login';

  const handleNavigate = (path: string) => {
    if (path.startsWith('#')) {
      const id = path.substring(1);
      if (location.pathname !== '/') {
        navigate('/');
        setTimeout(() => {
          document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      navigate(path);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F9FB] font-inter">
      <Toaster position="top-right" expand={true} richColors />
      
      {!isDashboard && !isAuth && (
        <Navbar 
          onNavigate={handleNavigate} 
          isLoggedIn={!!user}
          userRole={user?.role || null}
        />
      )}

      <main>
        <Outlet />
      </main>

      {!isDashboard && !isAuth && (
        <footer className="bg-white py-12 border-t border-gray-100">
          <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-2xl font-bold text-[#00B8C4]">DENS32</div>
            <p className="text-gray-400 text-sm">© 2026 DENS32 Clínica Dental. Todos los derechos reservados.</p>
            <div className="flex gap-6">
              <span className="text-gray-400 hover:text-[#00B8C4] cursor-pointer">Facebook</span>
              <span className="text-gray-400 hover:text-[#00B8C4] cursor-pointer">Instagram</span>
              <span className="text-gray-400 hover:text-[#00B8C4] cursor-pointer">LinkedIn</span>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
};
