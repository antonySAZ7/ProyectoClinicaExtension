import React, { useState, useEffect } from 'react';
import { Button } from './ui/shared';
import { Menu, X, User, LogOut, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppContext } from '../context/AppContext';
import { useNavigate } from 'react-router';

export const Navbar = ({ onNavigate, isLoggedIn, userRole }: { 
  onNavigate: (path: string) => void, 
  isLoggedIn: boolean,
  userRole: 'client' | 'admin' | null
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, logout } = useAppContext();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Sobre Nosotros', path: '#sobre-nosotros' },
    { label: 'Nuestros Servicios', path: '#nuestros-servicios' },
    { label: 'Contáctanos', path: '#contáctanos' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white/80 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'
    }`}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        <div 
          className="text-2xl font-bold text-[#00B8C4] cursor-pointer" 
          onClick={() => onNavigate('/')}
        >
          DENS32
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {!isLoggedIn && navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => onNavigate(link.path)}
              className="text-gray-600 hover:text-[#00B8C4] font-medium transition-colors cursor-pointer"
            >
              {link.label}
            </button>
          ))}
          
          <div className="flex items-center gap-4">
            {isLoggedIn ? (
              <div className="flex items-center gap-4">
                {userRole === 'client' && (
                  <Button 
                    variant="ghost" 
                    className="flex items-center gap-2"
                    onClick={() => onNavigate('/booking')}
                  >
                    <Calendar size={18} />
                    Mis Citas
                  </Button>
                )}
                <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-50 rounded-full border border-gray-100">
                  <User size={16} className="text-[#00B8C4]" />
                  <span className="text-sm font-medium text-gray-700">{user?.name}</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                  title="Cerrar sesión"
                >
                  <LogOut size={20} />
                </button>
              </div>
            ) : (
              <Button onClick={() => onNavigate('/login')}>
                Reserva tu cita
              </Button>
            )}
          </div>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden p-2 text-gray-600"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-gray-100 overflow-hidden"
          >
            <div className="px-6 py-8 flex flex-col gap-6">
              {!isLoggedIn && navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => {
                    onNavigate(link.path);
                    setIsMobileMenuOpen(false);
                  }}
                  className="text-left text-lg font-medium text-gray-600"
                >
                  {link.label}
                </button>
              ))}
              <div className="pt-4 border-t border-gray-100">
                {isLoggedIn ? (
                  <div className="space-y-4">
                    <p className="font-bold text-[#00B8C4]">{user?.name}</p>
                    {userRole === 'client' && (
                      <button onClick={() => { onNavigate('/booking'); setIsMobileMenuOpen(false); }} className="block w-full text-left py-2 text-gray-600">Mis Citas</button>
                    )}
                    <button onClick={handleLogout} className="block w-full text-left py-2 text-red-500">Cerrar sesión</button>
                  </div>
                ) : (
                  <Button fullWidth onClick={() => { onNavigate('/login'); setIsMobileMenuOpen(false); }}>
                    Reserva tu cita
                  </Button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
