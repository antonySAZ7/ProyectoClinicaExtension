import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button, Input, Card } from './ui/shared';
import { motion as Motion, AnimatePresence } from 'motion/react';
import { useAppContext } from '../context/AppContext';
import { toast } from 'sonner';

interface AuthProps {
  isRegisterMode?: boolean;
  isAdminLogin?: boolean;
}

export const Auth = ({ isRegisterMode = false, isAdminLogin = false }: AuthProps) => {
  const [isLogin, setIsLogin] = useState(!isRegisterMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  
  const { login } = useAppContext();
  const navigate = useNavigate();

  const validate = () => {
    const newErrors: { [key: string]: string } = {};
    if (isAdminLogin) return true; // No validation for admin login
    
    if (!email) newErrors.email = 'El correo es obligatorio';
    if (!password) newErrors.password = 'La contraseña es obligatoria';
    if (!isLogin && !name) newErrors.name = 'El nombre es obligatorio';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    if (isAdminLogin) {
      login('admin', 'admin@dens32.com', 'Doc');
      navigate('/admin');
      toast.success('Sesión administrativa iniciada');
    } else {
      if (isLogin) {
        if (password.length < 6) {
          setErrors({ general: 'Correo o contraseña incorrectos' });
          toast.error('Correo o contraseña incorrectos');
        } else {
          login('client', email, 'Paciente Demo');
          navigate('/booking');
          toast.success('Bienvenido de nuevo');
        }
      } else {
        login('client', email, name);
        navigate('/booking');
        toast.success('Cuenta creada exitosamente');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F7F9FB] px-4">
      <Card className="w-full max-w-[400px] p-8 shadow-xl">
        <div className="text-center mb-8">
          <button onClick={() => navigate('/')} className="text-3xl font-bold text-[#00B8C4] mb-2 cursor-pointer bg-transparent border-none">DENS32</button>
          <p className="text-gray-500">
            {isAdminLogin ? 'Panel Administrativo' : isLogin ? 'Bienvenido de nuevo' : 'Crea tu cuenta'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {!isAdminLogin && (
            <>
              <AnimatePresence mode="wait">
                {!isLogin && (
                  <Motion.div
                    key="name-input"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                  >
                    <Input 
                      label="Nombre completo *" 
                      placeholder="Tu nombre" 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      error={errors.name}
                    />
                  </Motion.div>
                )}
              </AnimatePresence>

              <Input 
                label="Correo electrónico *" 
                placeholder="correo@ejemplo.com" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                error={errors.email}
              />
              
              <Input 
                label="Contraseña *" 
                type="password" 
                placeholder="••••••••" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                error={errors.password}
              />
            </>
          )}

          {isAdminLogin && (
            <div className="text-center py-4">
              <p className="text-gray-600 mb-4">Acceso directo para el personal médico de DENS32.</p>
            </div>
          )}

          {errors.general && (
            <p className="text-sm text-red-500 text-center">{errors.general}</p>
          )}
          
          <Button fullWidth type="submit">
            {isLogin ? 'Iniciar sesión' : 'Crear cuenta'}
          </Button>

          {!isAdminLogin && (
            <p className="text-center text-sm text-gray-500">
              {isLogin ? '¿No tienes cuenta? ' : '¿Ya tienes cuenta? '}
              <button 
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="text-[#00B8C4] font-semibold hover:underline bg-transparent border-none cursor-pointer"
              >
                {isLogin ? '¡Crea tu cuenta!' : 'Inicia sesión'}
              </button>
            </p>
          )}

          {isLogin && !isAdminLogin && (
             <div className="text-center">
                <button 
                  type="button"
                  onClick={() => navigate('/admin/login')}
                  className="text-xs text-gray-400 hover:underline bg-transparent border-none cursor-pointer"
                >
                  Acceso Personal Médico
                </button>
             </div>
          )}
        </form>
      </Card>
    </div>
  );
};
