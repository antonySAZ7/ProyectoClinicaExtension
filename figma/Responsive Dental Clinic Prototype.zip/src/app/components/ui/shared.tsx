import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'success' | 'ghost';
  fullWidth?: boolean;
}

export const Button = ({ 
  className, 
  variant = 'primary', 
  fullWidth,
  children, 
  ...props 
}: ButtonProps) => {
  const variants = {
    primary: 'bg-[#00B8C4] text-white hover:bg-[#0097A7]',
    secondary: 'bg-[#0097A7] text-white hover:bg-[#008391]',
    outline: 'border-2 border-gray-200 text-gray-600 hover:border-[#00B8C4] hover:text-[#00B8C4]',
    success: 'bg-[#22C55E] text-white hover:bg-[#1ea34d]',
    ghost: 'text-gray-600 hover:text-[#00B8C4] bg-transparent'
  };

  return (
    <button
      className={cn(
        'px-6 py-3 rounded-[14px] font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer',
        variants[variant],
        fullWidth ? 'w-full' : '',
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
};

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = ({ label, error, className, ...props }: InputProps) => {
  return (
    <div className="flex flex-col gap-1.5 w-full">
      {label && <label className="text-sm font-medium text-gray-500">{label}</label>}
      <input
        className={cn(
          'w-full px-4 py-3 rounded-[14px] border border-gray-200 outline-none transition-all',
          'focus:border-[#00B8C4] focus:ring-2 focus:ring-[#00B8C4]/10',
          error ? 'border-red-500' : '',
          className
        )}
        {...props}
      />
      {error && <span className="text-xs text-red-500 mt-1">{error}</span>}
    </div>
  );
};

export const Card = ({ children, className }: { children: React.ReactNode; className?: string }) => {
  return (
    <div className={cn('bg-white p-6 rounded-[16px] shadow-sm border border-gray-100', className)}>
      {children}
    </div>
  );
};
