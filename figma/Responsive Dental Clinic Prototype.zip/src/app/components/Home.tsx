import { useNavigate } from 'react-router';
import { Button, Card } from './ui/shared';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Stethoscope, Shield, Clock, Heart, Sparkles, Smile } from 'lucide-react';

export const Home = () => {
  const navigate = useNavigate();
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative h-[500px] w-full flex items-center justify-center overflow-hidden">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBkZW50YWwlMjBjbGluaWMlMjBpbnRlcmlvciUyMHByb2Zlc3Npb25hbCUyMGRlbnRpc3QlMjBzdXJnZXJ5fGVufDF8fHx8MTc3MTI4NzkxOHww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Clínica Dental Moderna"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 font-poppins">
            Tu sonrisa en las mejores manos
          </h1>
          <p className="text-lg md:text-xl mb-8 font-light max-w-2xl mx-auto">
            Tecnología moderna y atención personalizada
          </p>
          <Button 
            className="text-lg px-10 py-4"
            onClick={() => navigate('/login')}
          >
            Reservar ahora
          </Button>
        </div>
      </section>

      {/* Sobre Nosotros */}
      <section className="py-24 px-6 md:px-12 bg-white" id="sobre-nosotros">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-16">
          <div className="w-full md:w-[60%]">
            <h2 className="text-3xl font-bold text-gray-900 mb-6 font-poppins">Sobre Nosotros</h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              En DENS32, nos dedicamos a transformar sonrisas con la más alta tecnología y un equipo de profesionales apasionados. Nuestra misión es brindar una experiencia dental cómoda, segura y eficiente para toda la familia.
            </p>
            <p className="text-gray-600 text-lg leading-relaxed mb-8">
              Contamos con más de 15 años de experiencia, garantizando resultados excepcionales y un trato humano que nos distingue como líderes en salud dental.
            </p>
            <div className="grid grid-cols-2 gap-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#00B8C4]/10 flex items-center justify-center text-[#00B8C4]">
                  <Shield size={20} />
                </div>
                <span className="font-medium">100% Seguro</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#00B8C4]/10 flex items-center justify-center text-[#00B8C4]">
                  <Clock size={20} />
                </div>
                <span className="font-medium">Atención Rápida</span>
              </div>
            </div>
          </div>
          <div className="w-full md:w-[40%] rounded-2xl overflow-hidden shadow-2xl">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1759813641406-980519f58b1c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBkZW50YWwlMjBjbGluaWMlMjBzdGFmZiUyMHNtaWxpbmclMjB0ZWFtJTIwcHJvZmVzc2lvbmFsJTIwc3VyZ2VyeXxlbnwxfHx8fDE3NzE2OTkzNzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Consulta Dental"
              className="w-full h-auto object-cover"
            />
          </div>
        </div>
      </section>

      {/* Nuestros Servicios */}
      <section className="py-24 px-6 md:px-12 bg-[#F7F9FB]" id="nuestros-servicios">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4 font-poppins">Nuestros Servicios</h2>
            <p className="text-gray-500">Ofrecemos soluciones integrales para tu salud dental</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <ServiceCard 
              icon={<Sparkles className="text-[#00B8C4]" size={32} />}
              title="Limpieza Dental"
              description="Eliminamos sarro y manchas para mantener tus dientes brillantes y encías saludables."
            />
            <ServiceCard 
              icon={<Smile className="text-[#00B8C4]" size={32} />}
              title="Ortodoncia"
              description="Alineamos tu sonrisa con las técnicas más avanzadas, incluyendo brackets e Invisalign."
            />
            <ServiceCard 
              icon={<Heart className="text-[#00B8C4]" size={32} />}
              title="Extracciones"
              description="Procedimientos seguros y sin dolor para extracciones simples o de terceros molares."
            />
          </div>
        </div>
      </section>

      {/* Contáctanos */}
      <section className="py-24 px-6 md:px-12 bg-white" id="contáctanos">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 font-poppins">Contáctanos</h2>
          <form className="space-y-6 text-left">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-1.5">
                <label className="text-sm font-medium text-gray-500">Nombre</label>
                <input className="px-4 py-3 rounded-[14px] border border-gray-200 focus:border-[#00B8C4] outline-none" placeholder="Tu nombre" />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-sm font-medium text-gray-500">Correo</label>
                <input className="px-4 py-3 rounded-[14px] border border-gray-200 focus:border-[#00B8C4] outline-none" placeholder="correo@ejemplo.com" />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium text-gray-500">Mensaje</label>
              <textarea 
                className="px-4 py-3 rounded-[14px] border border-gray-200 focus:border-[#00B8C4] outline-none min-h-[150px]" 
                placeholder="¿Cómo podemos ayudarte?"
              />
            </div>
            <Button fullWidth>Enviar mensaje</Button>
          </form>
        </div>
      </section>
    </div>
  );
};

const ServiceCard = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => (
  <Card className="hover:translate-y-[-8px] transition-transform duration-300">
    <div className="w-16 h-16 rounded-2xl bg-[#00B8C4]/5 flex items-center justify-center mb-6">
      {icon}
    </div>
    <h3 className="text-xl font-bold mb-3 font-poppins">{title}</h3>
    <p className="text-gray-500 leading-relaxed">{description}</p>
  </Card>
);
